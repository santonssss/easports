import React from "react";

type Props = {};

const Filter = (props: Props) => {
  return <div className="filter">Filter</div>;
};

export default Filter;
