import "./Banner.css";
type Props = {};

const Banner = (props: Props) => {
  return (
    <div className="container">
      <article className="banner__article"></article>
    </div>
  );
};

export default Banner;
