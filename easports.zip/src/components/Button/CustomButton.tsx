import React from "react";

type Props = {
  text: string;
};

const CustomButton = ({ text }: Props) => {
  return <button className="comments__button">{text}</button>;
};

export default CustomButton;
